
library(itsmr)
library(glmnet)
library(vars)

#' ACF Function
#'
#' This function is for ACF plot without the first element(1).
#' @param data data
#' @param lag.max Time-lag
#' @keywords ACF
#' @export
#' @examples
#' acf2(data = huron, lag.max = 35)

acf2 <- function (data, lag.max = 35) {
  thr <- qnorm(1 - .05 / 2, mean = 0, sd = 1 / sqrt(length(data)))
  a1 <- acf(data, lag.max, plot = FALSE)
  x <- seq(1, lag.max, by = 1)
  y <- a1$acf[-1]
  
  plot(x, y, type = "h", xlab = "Lag", ylab = "ACF")
  abline(h = 0, col = "black")
  abline(h = -thr, col = "blue", lty = 2)
  abline(h = thr, col = "blue", lty = 2)
}


#' Classical Decomposition
#'
#' This function decompose time series by classical decomposition.
#' @param data data
#' @param d Number of observations per season
#' @param order Polynomial order (1 linear, 2 quadratic, etc.)
#' @importFrom stats filter
#' @importFrom itsmr season
#' @importFrom itsmr trend
#' @keywords Classical decomposition
#' @export
#' @examples
#' classical(data = Nile, d = 7, order = 2)

classical <- function (data, d, order) {
  n <- length(data)
  
  q <- if (d %% 2 != 0) (d - 1) / 2 else d / 2
  x1 <- c(rep(data[1], q), data, rep(data[n], q))
  ff <- if (d %% 2 == 0) c(.5, rep(1, 2 * q - 1), .5) / d else rep(1, 2 * q + 1) / d
  xx <- stats::filter(x1, ff, method = c("convolution"))
  mhat <- na.omit(xx)
  mhat <- as.numeric(mhat)
  
  z <- data - as.numeric(mhat)
  st <- season(z, d)
  
  mnew <- trend(data - st, order)
  
  fit <- mnew + st
  resi <- data - fit
  
  return(list(fit = fit, st = st, m = mnew, resi = resi, m1 = mhat))
}


#' Optimize ma.cv
#'
#' @param interval bandwidth interval
#' @param data data
#' @param l local parameter
#' @importFrom itsmr smooth.ma
#' @import stats
#' @keywords optimize MA.CV
#' @export
#' @examples
#' opt.ma.cv(interval = c(5, length(huron) / 2), data = huron, l = 1, tol = .Machine$double.eps^0.25)

opt.ma.cv <- function (interval = interval, data = data, l = l, tol = .Machine$double.eps^0.25) {
  
  ma.cv <- function (h, data, l) {
    data <- as.vector(data)
    n <- length(data)
    cv <- 0
    ind <- 1:n
    eps <- 1.0e-16
    
    for (i in 1:n) {
      del <- seq(max(i - l, 1), min(i + l, n), by = 1)
      id <- ind[-del]
      Z <-  data[-del]
      tmp <- (id - i) / h
      s0 <- (abs(tmp) <= 1)
      s1 <- Z * s0
      m <- sum(s1) / max(eps, sum(s0))
      cv <- cv + (data[i] - m)^2
    }
    return(cv / n)
  }
  h.ma <- optimize(f = ma.cv, interval = interval, data = data, l = l, tol = tol)
  out.ma <- itsmr::smooth.ma(data, h.ma$minimum)
  
  return(list(h.ma = h.ma$minimum, out.ma = out.ma))
}


#' Least Angle Regression
#'
#' Perform Least Angle Regression (LARS).
#' @param X multivariate data
#' @param y response data
#' @param k number of folds
#' @keywords lars
#' @importFrom glmnet glmnet
#' @importFrom glmnet cv.glmnet
#' @importFrom stats predict
#' @export
#' @examples
#' result <- mylars(X = mv_data[, 2:6], y = mv_data[, 1], k = 10, use.Gram = TRUE, normalize = TRUE, intercept = TRUE)
#' print(result)

mylars <- function (X, y, k = 10, use.Gram = TRUE, normalize = TRUE, intercept = TRUE) {
  
  n <- length(y)
  all.folds <- split(sample(1:n), rep(1:k, length = n))
  if (use.Gram == TRUE) {
    type <- "covariance"
  } else {
    type <- "naive"
  }
  globalfit <- glmnet(X, y, family = "gaussian", standardize = normalize, type.gaussian = type, intercept = intercept)
  lambda <- globalfit$lambda
  residmat <- matrix(0, length(lambda), k)
  for (i in seq(k)) {
    omit <- all.folds[[i]]
    fit <- glmnet(X[-omit, , drop = FALSE], y[-omit], type.gaussian = type, standardize = normalize, family = "gaussian", intercept = intercept)
    fit <- predict(fit, newx = X[omit, , drop = FALSE], type = "response", s = lambda)
    if (length(omit) == 1) {
      fit <- matrix(fit, nrow = 1)
    }
    residmat[, i] <- apply((y[omit] - fit)^2, 2, mean)
  }
  cv <- apply(residmat, 1, mean)
  cv.lasso <- min(cv)
  cv.error <- sqrt(apply(residmat, 1, var) / k)
  lambda.opt <- lambda[which.min(cv)]
  coefficients <- predict(globalfit, type = "coefficients", s = lambda.opt)
  inter <- coefficients[1]
  coefficients <- coefficients[-1]
  names(coefficients) <- 1:ncol(X)
  object <- list(lambda = lambda, cv = cv, lambda.opt = lambda.opt, cv.lasso = cv.lasso, intercept = inter, coefficients = coefficients)
  invisible(object)
}


#' adaptiveLasso
#'
#' Perform adaptive lasso.
#' @param X multivariate matrix
#' @param y response vector
#' @param k number of folds
#' @importFrom glmnet glmnet
#' @importFrom stats predict
#' @keywords adaptiveLasso
#' @export
#' @examples
#' adaplasso(X = mv_data[, 2:6], y = mv_data[, 1], k = 10, use.Gram = TRUE, both = TRUE, intercept = TRUE)

adaplasso <- function (X, y, k = 10, use.Gram = TRUE, both = TRUE, intercept = TRUE) {
  colnames(X) <- 1:ncol(X)
  n <- length(y)
  cv.adalasso <- NULL
  globalfit <- mylars(X, y, k = k, use.Gram = use.Gram, normalize = TRUE, intercept = intercept)
  coefficients.lasso <- globalfit$coefficients
  intercept.lasso <- globalfit$intercept
  cv.lasso <- globalfit$cv.lasso
  lambda <- globalfit$lambda
  lambda.lasso <- globalfit$lambda.opt
  coefficients.adalasso <- NULL
  lambda.adalasso <- intercept.adalasso <- NULL
  if (use.Gram == TRUE) {
    type <- "covariance"
  } else {
    type <- "naive"
  }
  if (both == TRUE) {
    all.folds <- split(1:n, rep(1:k, each = floor(n / k)+1)[1:n])
    residmat <- matrix(0, length(lambda), k)
    for (i in seq(k)) {
      omit <- all.folds[[i]]
      Xtrain <- X[-omit, , drop = FALSE]
      ytrain <- y[-omit]
      Xtest <- X[omit, , drop = FALSE]
      ytest <- y[omit]
      my.lars <- mylars(Xtrain, ytrain, k = k, normalize = TRUE, use.Gram = use.Gram, intercept = intercept)
      coef.lasso <- my.lars$coefficients
      weights <- 1 / abs(coef.lasso[abs(coef.lasso) > 0])
      if (length(weights) == 0) {
        residmat[, i] <- mean((mean(ytrain) - ytest)^2)
      } else if (length(weights) == 1) {
        residmat[, i] = mean((ytest - my.lars$intercept - Xtest %*% coef.lasso)^2)
      } else if (length(weights) > 1) {
        XXtrain <- Xtrain[, names(weights), drop = FALSE]
        XXtest <- Xtest[, names(weights), drop = FALSE]
        XXtrain <- scale(XXtrain, center = FALSE, scale = weights)
        XXtest <- scale(XXtest, center = FALSE, scale = weights)
        fit <- glmnet(XXtrain, ytrain, type.gaussian = type, standardize = FALSE, intercept = intercept)
        pred <- predict(fit, newx = XXtest, type = "response", s = lambda)
        if (length(omit) == 1) {
          pred <- matrix(pred, nrow = 1)
        }
        residmat[, i] <- apply((ytest - pred)^2, 2, mean)
      }
    }
    cv <- apply(residmat, 1, mean)
    cv.adalasso <- min(cv)
    weights <- 1 / abs(coefficients.lasso[abs(coefficients.lasso) > 0])
    coefficients.adalasso <- rep(0, ncol(X))
    names(coefficients.adalasso) <- 1:ncol(X)
    
    if (length(weights) > 0) {
      XX <- X[, names(weights), drop = FALSE]
      if (length(weights) == 1) {
        XX <- XX / weights
      } else {
        XX <- scale(XX, center = FALSE, scale = weights)
      }
      if (length(weights) <= 1) {
        intercept.adalasso <- intercept.lasso
        coefficients.adalasso <- coefficients.lasso
        lambda.adalasso <- 0
      } else {
        fit <- glmnet(XX, y, type.gaussian = type, standardize = FALSE, intercept = intercept)
        lambda.adalasso <- lambda[which.min(cv)]
        coefficients <- predict(fit, type = "coefficients", s = lambda.adalasso)
        intercept.adalasso <- coefficients[1]
        coefficients.adalasso[names(weights)] <- coefficients[-1] / weights
      }
    }
  }
  return(list(cv.lasso = cv.lasso, lambda.lasso = lambda.lasso, cv.adalasso = cv.adalasso, lambda.adalasso = lambda.adalasso, intercept.lasso = intercept.lasso, intercept.adalasso = intercept.adalasso, coefficients.lasso = coefficients.lasso, coefficients.adalasso = coefficients.adalasso))
}


#' Autoregressive Adaptive Lasso function
#'
#' ar.adaplasso function automatically selects the order and zero coefficients all together
#' @param y response vector
#' @param p AR order
#' @param nf number of splits in k-fold cross validation
#' @importFrom stats ar 
#' @export
#' @examples 
#' simdata <- TSlibrary:::farima_sim(T = 500, d = 0.2, p = 2, q = NULL, sigma = 1, burn = 10)
#' ar.adaplasso(simdata, p = 2, nf = 10)

ar.adaplasso <- function (y, p, nf = 10, interceptTF=TRUE) {
  if(missing(p)){
    p <- ar(y, aic = TRUE, order.max = 10)$order
  }
  
  y <- as.vector(y)
  n <- length(y)
  mu.s <- mean(y)
  id <- 1:n
  X <- NULL
  for (j in 1:p) {
    id1 <- id - j
    id2 <- id1[id1 <= 0]
    id3 <- id1[id1 > 0]
    X <- cbind(X, c(rep(mu.s, length(id2)), y[id3]))
  }
  pp <- adaplasso(X, y, k = nf, intercept = interceptTF)
  return(pp)
}


#' Generating I(d) process Function
#'
#' Generating I(d) process.
#' @param n length of data
#' @param d d in FARIMA(0,d,0), d in (0,1/2)
#' @param sigma sigma
#' @keywords LRD
#' @export
#' @examples
#' cme_Id(n = 100, d = 0.2, sigma = 1)

cme_Id <- function (n, d, sigma = 1) {
  
  p <- ceiling(log2(2 * (n - 1)))
  k <- 1:(2^(p - 1))
  
  g0 <- gamma(1 - 2 * d) / (gamma(1 - d))^2
  rk <- (k - 1 + d) / (k - d)
  rk <- c(1, cumprod(rk))
  v <- rk * g0 * sigma^2
  
  id <- seq(from = 2, to = length(v) - 1, by = 1)
  u <- v[id]
  u <- u[length(u):1]
  z <- c(v, u)
  
  rm(u, v)
  
  w <- fft(z) / (2^p)
  
  rm(z)
  
  x <- rnorm(2^p, mean = 0, sd = 1)
  y <- rnorm(2^p, mean = 0, sd = 1)
  
  N <- complex(real = x, imaginary = y)
  N <- sqrt(w) * N
  M <- fft(N)
  
  S <- Re(M)
  data <- S[1:n]
  return(data)
}


#' Generating FARIMA(p,d,q) process Function
#'
#' Generating FARIMA(p,d,q) process with default burn-in 10.
#' @param T length of data
#' @param d FARIMA(p,d,q) with d in (0,1/2)
#' @param p AR order in FARIMA(p,d,q)
#' @param q MA order in FARIMA(p,d,q)
#' @param sigma sigma
#' @param burn number of burn-in
#' @importFrom stats filter
#' @export
#' @examples
#' farima_sim(T = 500, d = 0.2, p = 0, q = NULL, sigma = 1, burn = 10)

farima_sim <- function (T, d, p = 0, q = NULL, sigma = 1, burn = 10) {
  # Using burn-in size 10
  innov <- TSlibrary:::cme_Id(T + burn, d, sigma)
  
  data <- stats::filter(innov, c(1, q), sides = 1)
  data <- stats::filter(data, p, method = "recursive")
  id <- seq((burn + 1), (T + burn))
  data <- data[id]
  
  return(data)
}


#' Get Local Whittle Estimator(LWE) estimates and plot.
#'
#' Get LWE estimates and plotting them.
#' @param data data
#' @param m default: (data length)^(0.8)
#' @param int interval of frequencies in the LWE
#' @param lowerd lower d in FARIMA(p,d,q)
#' @param upperd upper d in FARIMA(p,d,q)
#' @param alpha Significance Level
#' @export
#' @examples
#' simdata<-farima_sim(1000,0.2)
#' lwe(data = simdata, m = length(simdata)^(.8), lowerd = -.5, upperd = 1, alpha = .025)

lwe <- function (data, m, int=5, lowerd = -.5, upperd = 1, alpha = .025) {
  T <- length(data)
  if (missing(m)) {
    m <- T^.8
  }
  
  m <- floor(m)
  
  M <- floor(T / 2)
  dft <- fft(data)
  dft <- dft[2:M]
  omega <- 2 * pi * (1:M) / T
  power <- (abs(dft)^2) / (2 * pi * T)
  nf <- seq(10, m, int)
  lwd <- 0 * seq(1:length(nf))
  
  lw_est <- function (d, omega, power, m) {
    lambda <- omega[1:m]
    Ix <- power[1:m]
    lwd <- log(mean((lambda^(2 * d)) * Ix)) - 2 * d * mean(log(lambda))
    return(lwd)
  }
  for (i in 1:length(lwd)) {
    est <- optim(.1, lw_est, omega = omega, power = power, m = nf[i], method = "L-BFGS-B", lower = lowerd, upper = upperd)
    lwd[i] <- est$par
  }
  
  ub <- lwd + qnorm(1 - alpha) / (2 * sqrt(nf))
  lb <- lwd - qnorm(1 - alpha) / (2 * sqrt(nf))
  
  plot(nf, lwd, type = "l", lty = 1, xlab = "Frequency", ylab = "d", ylim = c(min(lb) - .1, max(ub) + .1), lwd = 2)
  points(nf, ub, type = "l", lty = 2, col = "red")
  points(nf, lb, type = "l", lty = 2, col = "red")
  title('Local Whittle Estimator')
  
  out <- list()
  out$nf <- nf
  out$lwd <- lwd
  
  return(out)
}


#' Geweke and Porter-Hudak(GPH) estimates and plot.
#'
#' Get GPH estimates and plotting them.
#' @param data data
#' @param m default: length(data)^(2/3)
#' @param trim number of trimming
#' @param int interval of frequencies in the GPH plot
#' @param alpha Significance Level
#' @export
#' @examples
#' simdata <- farima_sim(1000, 0.2)
#' gph(data = simdata, m = length(simdata)^(2 / 3), trim = 1, alpha = 0.025)

gph <- function (data, m = length(data)^(2 / 3), trim = 1, int=5, alpha = .025){
  
  T <- length(data)
  trim <- floor(trim)
  m <- floor(m)
  
  M <- floor(T / 2)
  dft <- fft(data)
  dft <- dft[2:M]
  omega <- 2 * pi * seq(from = 1, to = M, by = 1) / T
  power <- (abs(dft)^2) / (2 * pi * T)
  y <- log(power)
  nf <- seq(10, m, int)
  gph <- 0 * seq(1:length(nf))
  for (i in 1:length(gph)) {
    x <- log(2 * sin(omega[trim:nf[i]] / 2))
    x.cen <- x - mean(x)
    gph[i] <- -.5 * sum(x.cen * y[trim:nf[i]]) / sum(x.cen^2)
  }
  
  ub <- gph + qnorm(1 - alpha) * sqrt(pi^2 / (24 * nf))
  lb <- gph - qnorm(1 - alpha) * sqrt(pi^2 / (24 * nf))
  
  plot(nf, gph, type = "l", lty = 1, xlab = "Frequency", ylab = "d", ylim = c(min(lb) - .1, max(ub) + .1), lwd = 2)
  points(nf, ub, type = "l", lty = 2, col = "red")
  points(nf, lb, type = "l", lty = 2, col = "red")
  title('Log Periodogram Estimator')
  
  out <- list()
  out$nf <- nf
  out$gph <- gph
  
  return(out)
}


#' sparse VAR with regular Lasso
#'
#' Perform sparse VAR with regular Lasso.
#' @param data data
#' @param p p
#' @param nf number of folds
#' @importFrom glmnet glmnet
#' @import vars
#' @keywords sVAR, lasso
#' @export
#' @examples
#' sVAR.lasso(data = data_varsim, p = 1, nf = 10)

sVAR.lasso <- function (data, p = 1, nf = 10) {
  y <- data - rowMeans(data)
  T1 <- dim(y)[2] - p
  k <- dim(y)[1]
  # create vector X1 and Y1
  X1 <- matrix(0, k * p, T1)
  Y1 <- matrix(0, k, T1)
  for (j in 1:T1) {
    # ar term
    id <- seq(from = j + p - 1, to = j, by = -1)
    x <- as.vector(y[, id])
    X1[, j] <- x
    Y1[, j] <- y[, (j + p)]
  }
  ty <- t(y)
  ty <- data.frame(ty)
  out <- VAR(ty, type = "none", p = p)
  Sig <- summary(out)$covres
  sv <- svd(Sig)
  hal <- sv$u %*% diag(1 / sqrt(sv$d)) %*% t(sv$v)
  y1 <- as.vector(Y1)
  x1 <- kronecker(t(X1), diag(1, k))
  
  diff <- 100
  iter <- 1
  while (diff >= .01 & iter < 5) {
    adjSig <- kronecker(diag(1, T1), hal)
    Y2 <- adjSig %*% y1
    X2 <- adjSig %*% x1
    cvfit <- cv.glmnet(X2, Y2, alpha = 1, intercept = TRUE, standardize = FALSE, type.measure = "mse", nfolds = nf)
    cf.cv <- coef(cvfit, s = "lambda.min")
    cf.cv <- cf.cv[-1]
    hA1 <- matrix(cf.cv, nrow = k, byrow = FALSE)
    Signew <- VAR.sigma(y, hA1)$Sigma_z
    diff <- sum((Sig - Signew)^2)
    Sig <- Signew
    iter <- iter + 1
    sv <- svd(Sig)
    hal <- sv$u %*% diag(1 / sqrt(sv$d)) %*% t(sv$v)
  }
  
  out <- list()
  out$cv <- cvfit
  out$hatA <- hA1
  out$lam <- cvfit$lambda.min
  out$Sigma_z <- Sig
  
  return(out)
  
}


#' sparse VAR with adaptiveLasso
#'
#' Perform sparse VAR with adaptiveLasso.
#' @param y data
#' @param p AR order
#' @param nf number of folds
#' @keywords LRD
#' @export
#' @examples
#' sVAR.adaplasso(y = data_varsim, p = 1, nf = 10)

sVAR.adaplasso <- function (y, p, nf = 10) {
  y <- y - rowMeans(y)
  k <- dim(y)[1]
  T <- dim(y)[2]
  T1 <- T - p
  
  # create vector X1 and Y1
  X1 <- matrix(0, k * p, T1)
  Y1 <- matrix(0, k, T1)
  for (j in 1:T1) {
    # ar term
    id <- seq(from = j + p - 1, to = j, by = -1)
    x <- as.vector(y[, id])
    X1[, j] <- x
    Y1[, j] <- y[, (j + p)]
  }
  
  y1 <- as.vector(Y1)
  x1 <- kronecker(t(X1), diag(1, k))
  
  hA0 <- kronecker(solve(X1 %*% t(X1)) %*% X1, diag(k)) %*% y1
  hA0 <- matrix(hA0, nrow = k)
  Sig <- VAR.sigma(y, hA0)$Sigma_z
  sv <- svd(Sig)
  hal <- sv$u %*% diag(1 / sqrt(sv$d)) %*% t(sv$v)
  
  hhA0 <- hA0
  diff <- 100
  iter <- 1
  while (diff >= .01 & iter < 5) {
    
    adjSig <- kronecker(diag(1, T1), hal)
    Y2 <- adjSig %*% y1
    X2 <- adjSig %*% x1
    
    pp <- adaplasso(X2, Y2, k = nf, intercept = FALSE)
    hA2 <- matrix(pp$coefficients.lasso, nrow = k)
    hA1 <- matrix(pp$coefficients.adalasso, nrow = k)
    diff <- sum((hA1 - hA0)^2)
    iter <- iter + 1
    hA0 <- hA1
    Sig <- VAR.sigma(y, hA0)$Sigma_z
    sv <- svd(Sig)
    hal <- sv$u %*% diag(1 / sqrt(sv$d)) %*% t(sv$v)
  }
  
  out <- list()
  out$cv <- pp$cv.adalasso
  out$hatA <- hA1
  out$lam <- pp$lambda.adalasso
  out$Sigma_z <- Sig
  ## standard LASSO result
  out$lasA <- hA2
  
  return(out)
}


#' Generating VAR(p) model
#'
#' Generating VAR(p) process with default burn-in 10
#' @param T length of time-series data
#' @param A coefficient matrix of model VAR
#' @param Sigma covariance matrix
#' @param burn number of burn-in
#' @importFrom MASS mvrnorm
#' @keywords VAR
#' @export
#' @examples
#' VAR.sim(T = 500, A = A, Sigma = Sigma)

VAR.sim <- function (T, A, Sigma, burn=10) {
  k <- dim(A)[1]
  p <- dim(A)[2] / k
  
  inno <- mvrnorm(n = T + burn, rep(0, k), Sigma)
  init <- mvrnorm(n = p, rep(0, k), Sigma)
  init <- matrix(init, nrow = p)
  
  # Find index for previous observations
  j <- 1
  # ar term
  id <- seq(from = j + p - 1, to = j, by = -1)
  
  Y <- matrix(0, (T + burn), k)
  for (r in 1:(T + burn)) {
    Y[r,] <- A %*% as.vector(t(init[id,])) + inno[r,]
    init <- rbind(init[-1,], Y[r,])
  }
  
  return(t(Y[-(1:burn),])) # Final data is k*T matrix
}


#' OLS estimation of VAR
#' 
#' Calculate VAR estimate by OLS method. 
#' @param y time-series data
#' @param p order of model VAR
#' @keywords VAR
#' @export
#' @examples
#' VAR.lse(y = data_varsim, p = 1)

VAR.lse  <- function (y, p) {
  y <- y - rowMeans(y)
  T <- dim(y)[2]
  T1 <- T - p
  k <- dim(y)[1]
  
  # create vector X1 and Y1
  X1 <- matrix(0, k * p, T1)
  Y1 <- matrix(0, k, T1)
  for (j in 1:T1) {
    # ar term
    id <- seq(from = j + p - 1, to = j, by = -1)
    x <- as.vector(y[, id])
    X1[, j] <- x
    Y1[, j] <- y[, (j + p)]
  }
  
  hatA <- Y1 %*% t(X1) %*% solve(X1 %*% t(X1))
  
  Resi <- matrix(0, k, T1)
  # residuals
  for (j in 1:T1) {
    id <- seq(from = j + p - 1, to = j, by = -1)
    x <- as.vector(y[, id])
    Resi[, j] <- y[, p + j]  - hatA %*% x
  }
  Sigma_z <- Resi %*% t(Resi) / T1
  bic <- T1 * log(det(Sigma_z)) + log(T1) * sum(hatA != 0)
  
  return(list(hatA = hatA, Sigma = Sigma_z, bic = bic, p = p))
}


#' Sigma estimation in VAR
#'
#' Estimate sigma in VAR 
#' @param y time-series data
#' @param hA1 estimated coefficient matrix of model VAR
#' @keywords VAR
#' @export
#' @examples
#' VAR.sigma(y = data_varsim, hA1 = A)

VAR.sigma <- function (y, hA1) {
  k <- dim(y)[1]
  T <- dim(y)[2]
  p <- dim(hA1)[2] / k
  T1 <- T - p
  
  # Calculate residuals
  Resi <- matrix(0, k, T1)
  for (j in 1:T1) {
    # ar term
    id <- seq(from = j + p - 1, to = j, by = -1)
    Resi[, j] <- y[, p + j] - hA1 %*% as.vector(y[, id])
  }
  
  # Estimate Sigma
  Sigma_z <- Resi %*% t(Resi) / T
  out <- list()
  out$Resi <- Resi
  out$Sigma_z <- Sigma_z
  
  return(out)
}


#' Forecasting VAR(p) model
#' 
#' Forecast values by VAR(p) 
#' @param y Multivariate Time series data
#' @param h length of time wanted to be forecasted
#' @param A coefficient matrix of model VAR
#' @keywords VAR
#' @export
#' @examples
#' VAR.forecast(data_varsim, h = 10, A = A) 

VAR.forecast <- function (y, h, A) {
  
  T1 <- dim(y)[2]
  k <- dim(A)[1]
  p <- dim(A)[2] / k
  
  # Find index for previous observations
  id <- seq(from = T1, to = T1 - p + 1, by = -1)
  
  Y1 <- Y <- matrix(0, k, h)
  for (r in 1:h) {
    Y[, r] <- A %*% as.vector(y[, id])   
    Y1[, r] <- Y[, r]
    y <- cbind(y[, -1], Y[, r])
  }
  
  return(Y1) # Final data is k*T matrix
}

